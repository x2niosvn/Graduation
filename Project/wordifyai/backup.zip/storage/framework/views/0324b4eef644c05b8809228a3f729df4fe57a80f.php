<!-- ask-openai-form.blade.php -->

<form action="/ask-openai" method="POST">
    <?php echo csrf_field(); ?>
    <label for="message">Enter your message:</label>
    <input type="text" id="message" name="message" value="<?php echo e(old('message')); ?>" required>
    <button type="submit">Send</button>
</form>

<?php if(isset($answer)): ?>
    <div class="mt-3">
        <strong>Response:</strong>
        <p><?php echo $answer; ?></p>
    </div>
<?php endif; ?>

<?php if(isset($error)): ?>
    <div class="mt-3 text-danger">
        <strong>Error:</strong>
        <p><?php echo e($error); ?></p>
    </div>
<?php endif; ?>
<?php /**PATH D:\LEARNING\wordifyai\resources\views/ask-openai-form.blade.php ENDPATH**/ ?>