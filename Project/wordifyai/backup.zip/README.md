** Project: Text analys and evaluation with AI - WordifyAI**

## Description

This project is a text analysis and evaluation tool that uses AI to analyze and evaluate text. The tool is designed to help users understand the content of a text and evaluate its quality. The tool uses natural language processing techniques to analyze the text and provide insights into its content. The tool can be used to analyze any type of text, including articles, essays, and reports. The tool is designed to be easy to use and can be accessed through a web interface.

Team Members:

- [Nguyen Xuan Nam](https://github.com/x2niosvn) -  Student ID: BH00794
- [Nguyen Ha Trung Phong](https://) -  Student ID: 
- [Nguyen Gia Bao]() -  Student ID: BH00795
- [Vu Le Manh Cuong]() -  Student ID: 

